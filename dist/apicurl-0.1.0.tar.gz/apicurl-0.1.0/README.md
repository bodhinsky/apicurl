## Simple pip installable Python package template

Run

```
pip install -e .
```

to use in dev mode!

Run tests with

```
pytest
```
