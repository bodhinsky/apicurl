import json
import pandas as pd

def export_to_dataframe(collection_info):
    if not collection_info:
        return None
    
    with open("./data/Collection.json", "w", encoding="utf-8") as f:
        json.dump(collection_info, f, ensure_ascii=False, indent=4)

    return pd.DataFrame(collection_info)

def export_to_xlsx(dataframe):
    with pd.ExcelWriter('./data/Record_Collection.xlsx', engine='openpyxl') as writer:
        dataframe.to_excel(writer, sheet_name='All Releases')
